function updateClock() {
    const clockElement = document.getElementById("clock");
    
    // Get current date and time
    const now = new Date();
    
    // Get hours, minutes, and seconds
    let hours = now.getHours();
    let minutes = now.getMinutes();
    let seconds = now.getSeconds();

    // Add leading zero for single-digit minutes and seconds
    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    // Format the time as HH:MM:SS
    const time = `${hours}:${minutes}:${seconds}`;

    // Update the clock display
    clockElement.textContent = time;
}

// Update the clock every second
setInterval(updateClock, 1000);

// Initial call to display the clock immediately
updateClock();
